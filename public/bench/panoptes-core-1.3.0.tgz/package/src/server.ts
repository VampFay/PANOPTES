/**
 * PANOPTES sidecar — an HTTP mediation service.
 *
 * Runs the engine as a stateful process beside the agent host:
 *
 *   bun run src/cli.ts serve --policy examples/policies/bench.json \
 *        --port 8787 --token <secret> --audit audit.jsonl
 *
 * Binds 127.0.0.1 by default (--host / PANOPTES_HOST to override — e.g.
 * 0.0.0.0 when fronted by your own TLS-terminating proxy).
 *
 * Sessions hold one `Observatory` each (ledger + canary registry are
 * per-session; the policy is shared). Every mediated call lands in the
 * audit stream. REST + JSON, OpenAPI 3.1 spec served at /openapi.json.
 *
 * This is a reference sidecar: front it with TLS and your authn/proxy
 * stack in production, and keep the port inside the agent host's trust
 * domain.
 */

import http from 'node:http';
import { watch } from 'node:fs';
import { Observatory, type PolicyDoc, type Label } from './core/v2';
import { loadPolicy } from './policy-load';
import { AuditedSession, JsonlAuditSink, CompositeSink, type AuditEvent } from './audit';
import { OPENAPI_SPEC } from './openapi';
import { VERSION } from './version';

type SessionRecord = {
  session: AuditedSession;
  events: AuditEvent[];
  tenantId: string;
  lastAccess: number;
};

type LedgerEntry = { label: Label; digest: string; outDigest?: string };

const MAX_BODY_BYTES = 1_048_576; // 1 MB cap

/**
 * Bounded ledger map capped per tenant at cap entries (default 65,536).
 * Evicts oldest clean entries first; ratchets fail-closed if tainted entries overflow.
 */
export class BoundedLedger extends Map<string, LedgerEntry> {
  readonly cap: number;
  private onOverflowFailClosed?: () => void;

  constructor(cap = 65_536, onOverflowFailClosed?: () => void) {
    super();
    this.cap = cap;
    this.onOverflowFailClosed = onOverflowFailClosed;
  }

  isTainted(entry: LedgerEntry): boolean {
    return !entry.label.audience.has('public');
  }

  override set(key: string, value: LedgerEntry): this {
    if (this.has(key)) {
      super.set(key, value);
      return this;
    }
    if (this.size >= this.cap) {
      // Find oldest clean entry (Map preserves insertion order)
      let cleanKey: string | undefined;
      for (const [k, v] of this.entries()) {
        if (!this.isTainted(v)) {
          cleanKey = k;
          break;
        }
      }
      if (cleanKey !== undefined) {
        this.delete(cleanKey);
      } else {
        // Tainted entries overflow! Evict oldest and ratchet fail-closed
        const oldest = this.keys().next().value;
        if (oldest !== undefined) {
          this.delete(oldest);
        }
        if (this.onOverflowFailClosed) {
          this.onOverflowFailClosed();
        }
      }
    }
    super.set(key, value);
    return this;
  }
}

/** In-memory ring + optional JSONL file sink per session. */
class MemorySink {
  readonly events: AuditEvent[] = [];
  private readonly cap: number;
  constructor(cap = 10_000) {
    this.cap = cap;
  }
  write(event: AuditEvent): void {
    this.events.push(event);
    if (this.events.length > this.cap) this.events.splice(0, this.events.length - this.cap);
  }
}

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: { 'content-type': 'application/json' },
  });
}

/** Constant-time string equality for bearer-token comparison — a plain
 *  `===` on the Authorization header leaks match length over a timing
 *  channel (v1.2.0 audit hardening). Token LENGTH is not treated as
 *  secret; only the comparison itself is made constant-time. */
function timingSafeEqualStr(a: string, b: string): boolean {
  const max = Math.max(a.length, b.length);
  let diff = a.length ^ b.length;
  for (let i = 0; i < max; i++) {
    diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  }
  return diff === 0;
}

export async function serve(rest: string[]): Promise<number> {
  const flags: Record<string, string | boolean> = {};
  for (let i = 0; i < rest.length; i++) {
    const a = rest[i]!;
    if (a.startsWith('--') && rest[i + 1] && !rest[i + 1]!.startsWith('--')) {
      flags[a.slice(2)] = rest[i + 1]!;
      i += 1;
    } else if (a.startsWith('--')) {
      flags[a.slice(2)] = true;
    }
  }
  const port = Number(flags.port ?? process.env.PANOPTES_PORT ?? 8787);
  const policyPath =
    typeof flags.policy === 'string' ? flags.policy : (process.env.PANOPTES_POLICY ?? 'examples/policies/bench.json');
  const token = (typeof flags.token === 'string' && flags.token) || process.env.PANOPTES_TOKEN || '';
  const auditPath = typeof flags.audit === 'string' ? flags.audit : undefined;
  const perSessionMemory = flags['per-session-memory'] === true;
  const silentNotes = flags['silent-notes'] === true || process.env.PANOPTES_SILENT_NOTES === '1';
  const watchPolicy = flags.watch === true || process.env.PANOPTES_WATCH === '1';
  const sessionTtlMs = Math.max(10_000, Number(flags['session-ttl'] ?? process.env.PANOPTES_SESSION_TTL_MS ?? 3600_000));
  const maxLedgerEntries = Math.max(100, Number(flags['max-ledger-entries'] ?? process.env.PANOPTES_MAX_LEDGER_ENTRIES ?? 65_536));

  const hostname =
    typeof flags.host === 'string' && flags.host
      ? flags.host
      : (process.env.PANOPTES_HOST ?? '127.0.0.1');
  const maxSessions = Math.max(1, Number(flags['max-sessions'] ?? process.env.PANOPTES_MAX_SESSIONS ?? 4_096));

  let policy: PolicyDoc;
  try {
    policy = loadPolicy(policyPath);
  } catch (e) {
    console.error(`panoptes serve: cannot load policy "${policyPath}": ${(e as Error).message}`);
    return 2;
  }

  if (watchPolicy) {
    try {
      watch(policyPath, (eventType) => {
        if (eventType === 'change' || eventType === 'rename') {
          try {
            const newPolicy = loadPolicy(policyPath);
            policy = newPolicy;
            console.log(`[panoptes] reloaded policy from ${policyPath} (${newPolicy.tools.length} tools)`);
          } catch (err) {
            console.error(`[panoptes] failed to reload policy: ${(err as Error).message}`);
          }
        }
      });
    } catch (err) {
      console.warn(`[panoptes] unable to watch policy file: ${(err as Error).message}`);
    }
  }

  type TenantState = {
    ledger: BoundedLedger;
    sessionIds: Set<string>;
    faulted?: boolean;
    faultReason?: string;
  };
  const tenants = new Map<string, TenantState>();

  function getTenant(tenantId: string): TenantState {
    let t = tenants.get(tenantId);
    if (!t) {
      t = {
        ledger: new BoundedLedger(maxLedgerEntries, () => {
          if (t) {
            t.faulted = true;
            t.faultReason = `shared ledger capacity exceeded (${maxLedgerEntries} tainted entries)`;
            for (const sId of t.sessionIds) {
              const r = sessions.get(sId);
              r?.session.fault(t.faultReason);
            }
          }
        }),
        sessionIds: new Set(),
      };
      tenants.set(tenantId, t);
    }
    return t;
  }

  const sessions = new Map<string, SessionRecord>();
  let seq = 0;

  function evictIdleSessions(): void {
    const now = Date.now();
    for (const [id, rec] of sessions.entries()) {
      if (now - rec.lastAccess > sessionTtlMs) {
        sessions.delete(id);
        tenants.get(rec.tenantId)?.sessionIds.delete(id);
      }
    }
  }

  const ttlTimer = setInterval(evictIdleSessions, 60_000);
  ttlTimer.unref?.();

  const unauthorized = () => json({ error: 'unauthorized — provide Authorization: Bearer <token>' }, 401);

  const authed = (req: Request): boolean => {
    if (!token) return true; // dev mode: no token configured
    const header = req.headers.get('authorization') ?? '';
    return timingSafeEqualStr(header, `Bearer ${token}`);
  };

  const getRecord = (id: string, reqTenant?: string): SessionRecord | null => {
    const r = sessions.get(id);
    if (!r) return null;
    if (reqTenant && r.tenantId !== reqTenant) return null;
    r.lastAccess = Date.now();
    return r;
  };

  const readJson = async (req: Request): Promise<{ ok: true; data: Record<string, unknown> } | { ok: false; status: number; error: string }> => {
    const len = Number(req.headers.get('content-length') ?? 0);
    if (len > MAX_BODY_BYTES) {
      return { ok: false, status: 413, error: 'payload too large' };
    }
    try {
      const text = await req.text();
      if (text.length > MAX_BODY_BYTES) {
        return { ok: false, status: 413, error: 'payload too large' };
      }
      if (!text.trim()) return { ok: true, data: {} };
      const parsed = JSON.parse(text);
      if (typeof parsed === 'object' && parsed !== null) {
        return { ok: true, data: parsed as Record<string, unknown> };
      }
      return { ok: false, status: 400, error: 'invalid JSON body' };
    } catch {
      return { ok: false, status: 400, error: 'invalid JSON body' };
    }
  };

  async function handleRequest(req: Request): Promise<Response> {
    const url = new URL(req.url);
    const path = url.pathname;

    // ---------- infrastructure -----------------------------------------
    if (path === '/healthz') return json({ ok: true, service: 'panoptes', version: VERSION });
    if (path === '/readyz') {
      return json({
        ok: true,
        policy: { tools: policy.tools.length, trustChain: policy.trustChain },
        sessions: sessions.size,
      });
    }
    if (path === '/openapi.json') return json(OPENAPI_SPEC);

    if (!authed(req)) return unauthorized();

    const reqTenant = req.headers.get('x-panoptes-tenant') || undefined;

    // ---------- session lifecycle --------------------------------------
    if (path === '/v1/sessions' && req.method === 'POST') {
      const bodyRes = await readJson(req);
      if (!bodyRes.ok) return json({ error: bodyRes.error }, bodyRes.status);
      const body = bodyRes.data;

      const tenantId = (reqTenant || (typeof body.tenantId === 'string' ? body.tenantId : '') || 'default').trim() || 'default';
      const tenant = getTenant(tenantId);

      const canaries = Array.isArray(body.canaries)
        ? (body.canaries as unknown[]).filter((c): c is string => typeof c === 'string' && c.length > 0)
        : [];
      const id = `s${Date.now().toString(36)}-${(seq++).toString(36)}`;
      
      evictIdleSessions();
      while (sessions.size >= maxSessions) {
        const oldest = sessions.keys().next().value;
        if (oldest === undefined) break;
        const oldRec = sessions.get(oldest);
        if (oldRec) tenants.get(oldRec.tenantId)?.sessionIds.delete(oldest);
        sessions.delete(oldest);
      }
      const engine = new Observatory(policy, { organs: true, canaries, silentNotes });
      if (!perSessionMemory) engine.ledger = tenant.ledger;
      const memory = new MemorySink();
      const sinks = auditPath
        ? new CompositeSink(memory, new JsonlAuditSink(`${auditPath}.${id}`))
        : memory;
      const session = new AuditedSession(engine, sinks, id);
      if (tenant.faulted) {
        session.fault(tenant.faultReason ?? 'tenant ledger capacity exceeded');
      }
      tenant.sessionIds.add(id);
      sessions.set(id, { session, events: memory.events, tenantId, lastAccess: Date.now() });
      return json(
        {
          sessionId: id,
          tenantId,
          canariesEnrolled: canaries.length,
          boundary: {
            trust: policy.trustChain[engine.currentLabel.trust] ?? engine.currentLabel.trust,
            audience: [...engine.currentLabel.audience],
          },
        },
        201,
      );
    }

    const sessionMatch = /^\/v1\/sessions\/([^/]+)(?:\/(check|observe|answer|world|rotate|fault|audit))?$/.exec(path);
    if (!sessionMatch) return json({ error: 'not found' }, 404);
    const [, id, action] = sessionMatch;
    const record = getRecord(id!, reqTenant);
    if (!record) return json({ error: `unknown session "${id}"` }, 404);
    const { session } = record;

    if (!action) {
      const label = session.engine.currentLabel;
      return json({
        sessionId: id,
        tenantId: record.tenantId,
        stats: session.stats,
        flow: { trust: policy.trustChain[label.trust] ?? label.trust, audience: [...label.audience] },
        canaryGeneration: session.engine.canaryGeneration,
        failClosed: session.engine.failClosed,
      });
    }

    // ---------- mediation ----------------------------------------------
    switch (action) {
      case 'check': {
        if (req.method !== 'POST') return json({ error: 'POST required' }, 405);
        const bodyRes = await readJson(req);
        if (!bodyRes.ok) return json({ error: bodyRes.error }, bodyRes.status);
        const body = bodyRes.data;
        const tool = typeof body.tool === 'string' ? body.tool : '';
        if (!tool) return json({ error: 'field "tool" (string) required' }, 400);
        const args: Record<string, string> = {};
        if (body.args && typeof body.args === 'object' && !Array.isArray(body.args)) {
          for (const [k, v] of Object.entries(body.args as Record<string, unknown>)) {
            args[k] = typeof v === 'string' ? v : JSON.stringify(v);
          }
        }
        const mediation = session.check(tool, args);
        if (mediation.decision === 'allow') session.recordEffects(tool, args, mediation);
        return json(mediation);
      }
      case 'observe': {
        if (req.method !== 'POST') return json({ error: 'POST required' }, 405);
        const bodyRes = await readJson(req);
        if (!bodyRes.ok) return json({ error: bodyRes.error }, bodyRes.status);
        const body = bodyRes.data;
        const tool = typeof body.tool === 'string' ? body.tool : '';
        const output = typeof body.output === 'string' ? body.output : '';
        if (!tool) return json({ error: 'fields "tool" (string) and "output" (string) required' }, 400);
        const args: Record<string, string> = {};
        if (body.args && typeof body.args === 'object' && !Array.isArray(body.args)) {
          for (const [k, v] of Object.entries(body.args as Record<string, unknown>)) {
            args[k] = typeof v === 'string' ? v : JSON.stringify(v);
          }
        }
        const observation = session.observe(tool, args, output);
        return json(observation);
      }
      case 'answer': {
        if (req.method !== 'POST') return json({ error: 'POST required' }, 405);
        const bodyRes = await readJson(req);
        if (!bodyRes.ok) return json({ error: bodyRes.error }, bodyRes.status);
        const body = bodyRes.data;
        if (typeof (body as { draft?: unknown }).draft !== 'string') {
          return json({ error: 'field "draft" (string) required' }, 400);
        }
        return json(session.checkAnswer((body as { draft: string }).draft));
      }
      case 'world': {
        if (req.method !== 'POST') return json({ error: 'POST required' }, 405);
        const bodyRes = await readJson(req);
        if (!bodyRes.ok) return json({ error: bodyRes.error }, bodyRes.status);
        const body = bodyRes.data;
        if (typeof (body as { store?: unknown }).store !== 'string' || typeof (body as { content?: unknown }).content !== 'string') {
          return json({ error: 'fields "store" and "content" (strings) required' }, 400);
        }
        const b = body as { store: string; content: string };
        const before = session.engine.currentLabel;
        session.engine.enrollWorldCanaries(b.store, b.content);
        return json({
          enrolled: true,
          sensitive: policy.sensitiveStores?.includes(b.store) ?? false,
          canaryGeneration: session.engine.canaryGeneration,
          flowUnchanged: before === session.engine.currentLabel,
        });
      }
      case 'rotate': {
        if (req.method !== 'POST') return json({ error: 'POST required' }, 405);
        return json(session.rotateCanaries());
      }
      case 'fault': {
        if (req.method !== 'POST') return json({ error: 'POST required' }, 405);
        const bodyRes = await readJson(req);
        const body = bodyRes.ok ? bodyRes.data : {};
        const reason = body && typeof (body as { reason?: unknown }).reason === 'string'
          ? (body as { reason: string }).reason
          : 'operator-declared integrity fault';
        session.fault(reason);
        return json({ failClosed: session.engine.failClosed, reason });
      }
      case 'audit': {
        const limit = Math.max(1, Math.min(10_000, Number(url.searchParams.get('limit') ?? 200)));
        const events = record.events.slice(-limit);
        return json({ sessionId: id, count: events.length, events });
      }
      default:
        return json({ error: 'not found' }, 404);
    }
  }

  if (typeof Bun !== 'undefined' && Bun.serve) {
    const server = Bun.serve({
      port,
      hostname,
      fetch: handleRequest,
    });
    console.log(`panoptes serve (bun) — listening on ${hostname}:${server.port}`);
  } else {
    const nodeServer = http.createServer(async (nodeReq, nodeRes) => {
      try {
        const url = `http://${nodeReq.headers.host || `${hostname}:${port}`}${nodeReq.url}`;
        const headers = new Headers();
        for (const [k, v] of Object.entries(nodeReq.headers)) {
          if (v === undefined) continue;
          if (Array.isArray(v)) {
            for (const item of v) headers.append(k, item);
          } else {
            headers.set(k, v);
          }
        }
        let body: Buffer[] | null = null;
        if (nodeReq.method !== 'GET' && nodeReq.method !== 'HEAD') {
          const chunks: Buffer[] = [];
          let total = 0;
          for await (const chunk of nodeReq) {
            total += (chunk as Buffer).length;
            if (total > MAX_BODY_BYTES) {
              nodeRes.writeHead(413, { 'content-type': 'application/json' });
              nodeRes.end(JSON.stringify({ error: 'payload too large' }, null, 2));
              return;
            }
            chunks.push(chunk as Buffer);
          }
          body = chunks;
        }
        const webReq = new Request(url, {
          method: nodeReq.method,
          headers,
          body: body && body.length > 0 ? Buffer.concat(body) : undefined,
          duplex: 'half',
        } as RequestInit & { duplex?: string });
        const webRes = await handleRequest(webReq);
        nodeRes.writeHead(webRes.status, Object.fromEntries(webRes.headers.entries()));
        const resText = await webRes.text();
        nodeRes.end(resText);
      } catch (err) {
        nodeRes.writeHead(500, { 'content-type': 'application/json' });
        nodeRes.end(JSON.stringify({ error: (err as Error).message }, null, 2));
      }
    });
    nodeServer.listen(port, hostname, () => {
      console.log(`panoptes serve (node) — listening on ${hostname}:${port}`);
    });
  }

  console.log(`  policy: ${policyPath} (${policy.tools.length} tools, chain ${policy.trustChain.join(' < ')})`);
  console.log(`  auth:   ${token ? 'bearer token required' : 'NONE (dev mode — set --token or PANOPTES_TOKEN)'}`);
  console.log(`  memory: ${perSessionMemory ? 'per-session ledger (isolated)' : 'shared cross-session ledger (O4 taint carries)'}`);
  console.log(`  audit:  ${auditPath ? `JSONL per session (${auditPath}.<sessionId>)` : 'in-memory ring (last 10,000 events/session)'}`);
  console.log(`  limits: ${maxSessions} sessions (oldest evicted), ledger cap ${maxLedgerEntries}/tenant`);
  console.log(`  spec:   http://${hostname}:${port}/openapi.json`);

  // Run until interrupted.
  await new Promise<never>(() => {
    /* serve until SIGINT/SIGTERM */
  });
  return 0;
}
